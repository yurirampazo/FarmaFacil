package com.FarmaFacil.Farma;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FarmaApplication {

	public static void main(String[] args) {
		SpringApplication.run(FarmaApplication.class, args);
	}

}
