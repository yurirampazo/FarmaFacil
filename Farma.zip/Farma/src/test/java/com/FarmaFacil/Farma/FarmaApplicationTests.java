package com.FarmaFacil.Farma;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FarmaApplicationTests {

	@Test
	void contextLoads() {
	}

}
